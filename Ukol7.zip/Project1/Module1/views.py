from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

from Module1.forms.contactForm import ContactForm
from Module1.forms.registerForm import RegisterForm



def index(request):
    template = loader.get_template('index.html')

    items = ["kalhoty", "košile", "kabát", "rukavice"]

    user_name = "Karel Vomáčka"

    content = {
        "title": "Hlavní titulek",
        "text": "Hlavní text",
        "items": items,
        "user_name": user_name,
        "price": 100,
    }
    return HttpResponse(template.render(content, request))


def article(request, id: int):
    print(type(id))
    template = loader.get_template('article.html')

    articles = [
        {"title": "Článek 1", "text": "Obsah článku 1"},
        {"title": "Článek 2", "text": "Obsah článku 2"},
        {"title": "Článek 3", "text": "Obsah článku 3"},
    ]

    content = {
        "article": articles[id-1],
    }
    return HttpResponse(template.render(content, request))


def test(request):
    template = loader.get_template('test.html')

    items = ["jablka", "hrušky", "švestky", "ořechy"]

    content = {
        "title": "Testovací titulek",
        "text": "Testovací text",
        "items": items,
    }
    return HttpResponse(template.render(content, request))


def pokus(request):
    template = loader.get_template('pokus.html')

    content = {
        "title": "Pokusný titulek",
        "text": "Pokusný text",
    }
    return HttpResponse(template.render(content, request))


def gallery(request):
    template = loader.get_template('gallery.html')

    pictures = ["img/tux.png", "img/python.png", "img/django.png", "img/tux.png", "img/python.png", "img/tux.png", "img/django.png", "img/python.png"]

    content = {
        "title": "Fotogalerie",
        "pictures": pictures,
    }
    return HttpResponse(template.render(content, request))


def contacts(request):
    template = loader.get_template('contacts.html')

    if request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            nick = form.cleaned_data['nick']
            email = form.cleaned_data['email']
            print(nick)

            # send_mail()
    else:
        form = ContactForm()

    content = {
        "title": "Kontakty",
        "form": form,
    }
    return HttpResponse(template.render(content, request))


def register(request):
    template = loader.get_template('register.html')

    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            jmeno = form.cleaned_data['jmeno']
            prijmeni = form.cleaned_data['prijmeni']
            email = form.cleaned_data['email']
            vek = form.cleaned_data['vek']
            vzdelani = form.cleaned_data['vzdelani']
            print(jmeno, prijmeni, email, vek, vzdelani)
    else:
        form = RegisterForm()

    content = {
        "title": "Kontakty",
        "form": form,
    }
    return HttpResponse(template.render(content, request))

