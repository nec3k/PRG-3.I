from django import template

register = template.Library()


@register.filter(name='get_name')
def get_name(value):
    try:
        value = value[value.find('/')+1:]
    except ValueError:
        value = "???"
    return value
