from django import template

register = template.Library()


@register.filter(name='with_vat')
def with_vat(value):
    try:
        value = float(value) * 1.2
    except ValueError:
        value = "???"
    return str(value) + " Kč"
