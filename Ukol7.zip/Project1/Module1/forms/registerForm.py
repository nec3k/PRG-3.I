from django import forms


class RegisterForm(forms.Form):
	jmeno = forms.CharField(label='Jméno', max_length=50)
	prijmeni = forms.CharField(label='Příjmení', max_length=50)
	email = forms.EmailField(label="Email", max_length=100)
	vek = forms.IntegerField(label="Věk", required=False)
	vzdelani = forms.ChoiceField(label="Vzdělání ", choices=[['1', 'základní'], ['2', 'středoškolské'], ['3', 'vysokoškolské'], ['4', 'doktorské']])
