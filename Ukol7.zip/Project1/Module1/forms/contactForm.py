from django import forms


class ContactForm(forms.Form):
	nick = forms.CharField(label='Jméno Příjmení', max_length=100)
	email = forms.EmailField(label="Email", max_length=100)
	content = forms.CharField(label="Napište zprávu", max_length=1000)
	theme = forms.ChoiceField(label="Téma", choices=[['1', 'Nabídka'], ['2', 'Poptávka'], ['3', 'Dotaz']])
