from django.conf.urls import url
from Module1 import views
from django.urls import path

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^testovaci-strana$', views.test, name='test'),
    url(r'^pokusna-strana$', views.pokus, name='pokus'),
    url(r'^galerie$', views.gallery, name='gallery'),
    path('clanek/<int:id>', views.article),
    url(r'^kontakty$', views.contacts, name='contacts'),
    url(r'^register$', views.register, name='register'),
]
