from django import template

register = template.Library()


@register.inclusion_tag('tags/email_to.html', name="email_to")
def email_to(email):
    email = str(email)

    return {
        'email': email
    }