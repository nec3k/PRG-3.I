from django import template

register = template.Library()


@register.inclusion_tag('tags/top_menu.html', name="top_menu")
def top_menu(css_class):
    menu_list = [
        {"link": "index", "title": "Hlavní stranka"},
        {"link": "test", "title": "Testovací stranka"},
        {"link": "pokus", "title": "Pokusná stranka"},
    ]

    return {
        'menu_list': menu_list,
        'css_class': css_class,
    }


