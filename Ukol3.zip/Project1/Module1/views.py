from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader


def index(request):
    template = loader.get_template('index.html')

    items = ["kalhoty", "košile", "kabát", "rukavice"]

    user_name = "Karel Vomáčka"

    content = {
        "title": "Hlavní titulek",
        "text": "Hlavní text",
        "items": items,
        "user_name": user_name,
    }
    return HttpResponse(template.render(content, request))


def test(request):
    template = loader.get_template('test.html')

    items = ["jablka", "hrušky", "švestky", "ořechy"]

    content = {
        "title": "Testovací titulek",
        "text": "Testovací text",
        "items": items,
    }
    return HttpResponse(template.render(content, request))


def pokus(request):
    template = loader.get_template('pokus.html')

    content = {
        "title": "Pokusný titulek",
        "text": "Pokusný text",
    }
    return HttpResponse(template.render(content, request))


def jedna(request):
    template = loader.get_template('jedna.html')

    content = {
        "title": "První titulek",
    }
    return HttpResponse(template.render(content, request))


def dva(request):
    template = loader.get_template('dva.html')

    content = {
        "title": "Zajímavý titulek",
        "text": "Dlouhý text",
    }
    return HttpResponse(template.render(content, request))