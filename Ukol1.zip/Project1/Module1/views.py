from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader


def index(request):
    template = loader.get_template('index.html')
    content = {
        "title" : "Hlavní stranka",
        "text" : "Hlavní text",
    }
    return HttpResponse(template.render(content, request))


def test(request):
    template = loader.get_template('index.html')
    content = {
        "title" : "Testovací stranka",
        "text" : "Testovací text",
    }
    return HttpResponse(template.render(content, request))


def ukol1(request):
    template = loader.get_template('index.html')
    content = {
        "title" : "Úkol jedna",
        "text" : "První úkol",
    }
    return HttpResponse(template.render(content, request))
