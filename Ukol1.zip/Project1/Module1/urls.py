from django.conf.urls import url
from Module1 import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^test$', views.test, name='test'),
    url(r'^ukol1$', views.ukol1, name='ukol1')
]