from django.apps import AppConfig


class Module1Config(AppConfig):
    name = 'Module1'
