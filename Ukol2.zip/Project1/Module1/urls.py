from django.conf.urls import url
from Module1 import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^testovaci-strana$', views.test, name='test'),
    url(r'^pokusna-strana$', views.pokus, name='pokus'),
    url(r'^ukol-dva$', views.ukol_dva, name='ukol_dva'),
]
