from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader


def index(request):
    template = loader.get_template('index.html')
    cislo = 9
    items = ["kalhoty", "košile", "kabát", "rukavice"]

    user_name = "Karel Vomáčka"

    content = {
        "title": "Hlavní titulek",
        "text": "Hlavní text",
        "items": items,
        "user_name": user_name,
        "cislo": cislo,
    }
    return HttpResponse(template.render(content, request))


def test(request):
    template = loader.get_template('index.html')
    cislo = 1
    items = ["jablka", "hrušky", "švestky", "ořechy"]

    content = {
        "title": "Testovací titulek",
        "text": "Testovací text",
        "items": items,
    }
    return HttpResponse(template.render(content, request))


def pokus(request):
    template = loader.get_template('index.html')
    cislo = 5
    content = {
        "title": "Pokusný titulek",
        "text": "Pokusný text",
        "cislo": cislo,
    }
    return HttpResponse(template.render(content, request))


def ukol_dva(request):
    template = loader.get_template('index.html')
    #items = []
    items = ["modrá", "zelená", "černá", "bílá", "žlutá"]
    cislo = -6
    content = {
        "title": "Úkol dva",
        "text": "Druhý úkol",
        "items": items,
        "cislo": cislo,
    }
    return HttpResponse(template.render(content, request))